import java.util.*;
import java.io.InputStream;
/**
* A reader for files that you want to use within a Greenfoot project.
* Author(Darcy)
* 4/11/2019
*/
public class Reader 
{
    /**
    * Opens a text file inside the package folder and returns a scanner to
    * read it. This works for text files inside jar files.
    * 
    * @param name The name of the text file
    * @return A Scanner object that is used to read the contents of the text   
    *  file.
    */
    public Scanner getScanner(String filename){
        InputStream myFile = getClass().getResourceAsStream(filename);
        if(myFile != null){
            return new Scanner(myFile);
        }
        return null;
    }
    /* 
    * Example use of the Reader in the constructor for MyWorld.
    * This will read all words in the nouns.txt file into an arraylist
    */
    public ArrayList<String> getTextInput(String fileName)
    {
        Scanner input = getScanner(fileName);
        ArrayList<String> nounsList = new ArrayList<String>();
        while(input.hasNext())
        {
            nounsList.add(input.nextLine());
        }
      return nounsList;
    }

}
