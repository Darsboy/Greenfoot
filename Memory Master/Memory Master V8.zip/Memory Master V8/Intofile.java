/**
 * Write a description of class Intofile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.io.*;
import javax.swing.JOptionPane;
import java.util.*;
import javax.swing.*;

public class Intofile  
{
    // instance variables - replace the example below with your own
    private int x;
    public static Player currentPlaying=null;
    HashMap<String,Player> usernametoPlayer=new HashMap<String,Player>();


    /**
     * Constructor for objects of class Intofile
     */
    public Intofile()
    {
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static void sampleMethod()
    {
        // where you save:

        // 1) setup:
        // I don't know for sure if the file specified here has to already exist, you may need to research on that.
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("file.txt"));

            // 2) Create data to store

            // 3) Actually store the data.
            // You can do this by doing this:
            bw.write("Hello world"+"\n");
            bw.newLine();
            // for every line to save. Replace <string to save> with a String to save in the file.

            // 4) Close it:
            bw.close();
        } catch (Exception e) {
            System.err.println("Error: "+e.getMessage());
        }
    }  


    public static void getPlayer(){

        // a jframe here isn't strictly necessary, but it makes the example a little more real
        JFrame frame = new JFrame("InputDialog Example #1");

        // prompt the user to enter their name
        String name = JOptionPane.showInputDialog(frame, "Username");
        String Password = JOptionPane.showInputDialog(frame, "Password");
        if(usernametoPlayer.containsKey(name)&&Password.equals(usernametoPlayer.get(name).password)  ){
        
        
        
        }
        // get the user's input. note that if they press Cancel, 'name' will be null

    }

}
