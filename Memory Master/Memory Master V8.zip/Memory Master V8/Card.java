import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Card here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Card extends Actor
{
    /**
     * Act - do whatever the Card wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int rank,suit;
    Card(int rank,int suit){
        this.rank=rank;
        this.suit=suit;
        if(rank>=0&&suit>=0)
        setImage(StartWorld.cardsImages[rank][suit]);

    }
    boolean drag = false;
    boolean isDragged(){
        return drag;
    }

    boolean equals(Card p){
        return p.rank==this.rank&&p.suit==this.suit;
    }
/*
    public void act() 
    {
        MouseInfo mouse= Greenfoot.getMouseInfo();
        if(Greenfoot.mousePressed(this)) drag = true;
        if(Greenfoot.mouseClicked(null)) drag = false;

        if(drag) {
            setLocation(mouse.getX(),mouse.getY());
        }
    }    
    */
   public void act(){
            Game world=(Game)getWorld();
        if (Greenfoot.mouseClicked(this)&&world!=null) {
            world.selectedCard=this;
        }
 
    
    
    }
}
