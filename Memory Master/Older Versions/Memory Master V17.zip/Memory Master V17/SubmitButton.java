import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class submitButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SubmitButton extends ButtonTemp
{
    /**
     * 
     */
    SubmitButton() 
    {
        super(new GreenfootImage("SubmitButton.PNG"),new GreenfootImage("SubmitButtonInverted.png"),0.5);

    }    
}
