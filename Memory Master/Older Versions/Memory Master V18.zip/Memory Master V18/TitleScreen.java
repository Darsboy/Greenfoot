import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TitleScreen here.
 * 
 * @author (Mercedes) 
 * @version (May 2019)
 */
public class TitleScreen extends World
{
    
    /**
     * Constructor for objects of class TitleScreen.
     * 
     */
    Button button = new Button();
    public TitleScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Game.width, Game.height, 1); 
        
        BunchOfCards bunchOfCards = new BunchOfCards();
        addObject(bunchOfCards, getWidth()/2, getHeight()/2 - 200);
        
        // Title
        Label title = new Label("Memory Master", 90);
        title.setFillColor(Color.WHITE);
        title.setLineColor(Color.WHITE);
        addObject(title, getWidth()/2, getHeight()/2);
        
        // Subtitle
        Label subtitle = new Label("Are you up for a challenge?", 40);
        subtitle.setFillColor(Color.YELLOW);
        subtitle.setLineColor(Color.YELLOW);
        addObject(subtitle, getWidth()/2, getHeight()/2 + 80);
        
        addObject(button, getWidth()/2, getHeight()/2 + 150);
    }
    public void act()
    {
        if(Greenfoot.mouseClicked(button))
        {
            Greenfoot.setWorld(new Instructions());
        }
    }
}
