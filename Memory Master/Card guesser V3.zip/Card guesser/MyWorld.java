import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends greenfoot.World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    static int height=600,width=(int)(1.6*height);
    static GreenfootImage[][] cardsImages=new GreenfootImage[13][4];//rank and suit

    Vector<Card>cards=new Vector<Card>();//rank and suit

    HashMap<Card,Boolean>inserted=new HashMap<Card,Boolean>();
    Label numbers=new Label("",20);
    Label isRight=new Label("",20);
    Random rand=new Random();
    boolean pass=false;
    int difficulty=2;
    List<CardSlot> slots=new LinkedList<CardSlot>();
    SimpleTimer timer=new SimpleTimer();
    Button button=new Button();
    CardSlot testSlot=new CardSlot(new Card(0,0));
    
    public MyWorld()
    {   
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(width, height, 1); 
        initiateCards();
        shuffleCards(cards);
        addObject(button, 50,50);
        addObject(numbers,getWidth()/2,height-40);
        addObject(isRight,getWidth()/2,height-80);
        //addObject(testSlot,getWidth()/4,getHeight()/2);
    }

    public void generate(int start, int amuont,int typ){
        int imagelength=cardsImages[0][0].getWidth()+5;
        if(typ==0){
            for(int i=0; i<amuont*imagelength; i+=imagelength){

                slots.add(new CardSlot(cards.get(i/imagelength)));
                addObject(cards.get(i/imagelength),i+start,300);

            }
        }
        if(typ==1){
            removeCards();
            for(int i=0; i<amuont*imagelength; i+=imagelength){
                addObject(slots.get(i/imagelength),i+start,300);
            }

        }
    }

    public void initiateCards(){

        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                int imageNumber=suit*13+rank;
                String imageName=Integer.toString(imageNumber);
                if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);

                cardsImages[rank][suit]=new GreenfootImage("tile0"+imageName+".png");
                cards.add(new Card(rank,suit));
                //addObject(new Card(rank,suit),0,0);

            }
        }

    }

    public void removeCards(){
        List remove = getObjects( Card.class );

        if (remove != null) { removeObjects(remove); }
    }

    public Card  returnCard(){
        Object[] possibleValues = { "Ace", "2", "3","4","5","6","7","8","9","10","Jack","Queen","King" };
        HashMap<Object,Integer> mapInd = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValues.length;i++){
            mapInd.put(possibleValues[i],i);

        }
        Object selectedValue = JOptionPane.showInputDialog(null,"Choose rank", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValues, possibleValues[0]);

        Object[] possibleValuesSuit = {"Clovers","Heart","Spade","Diamond"};
        Object selectedValueSuit = JOptionPane.showInputDialog(null,"Choose rank", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValuesSuit, possibleValuesSuit[0]);

        HashMap<Object,Integer> mapIndSuit = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValuesSuit.length;i++){
            mapIndSuit.put(possibleValuesSuit[i],i);

        }
        //System.out.println(selectedValue+" "+selectedValueSuit);
        if(selectedValue==null||selectedValueSuit==null)return null;

        numbers.setValue(mapInd.get(selectedValue)+" "+mapIndSuit.get(selectedValueSuit));
        return new Card(mapInd.get(selectedValue),mapIndSuit.get(selectedValueSuit));

        //return new Card(mapInd.get(selectedValue),mapIndSuit.get(possibleValuesSuit));
    }

    public void shuffleCards(List<Card>cards){
        for(int i=0; i<cards.size(); i++){
            int randomIndex = rand.nextInt(52);
            Card x = cards.get(i);
            Card y =  cards.get(randomIndex);

            cards.set(i, y);
            cards.set(randomIndex, x);
        }
    }

    private boolean checkTrue(){
        boolean ret=true;
        for(CardSlot i:slots){
            ret=ret&&i.isRight();
        }
        return ret;
    } 
    boolean solving =false,started=false;
    public void act(){
        // press start
        if(Greenfoot.mouseClicked(button)){
            started=true;
            timer.mark();
            removeCards();
            generate(64,difficulty,0);
        }
        // new card
        if(Greenfoot.isKeyDown("space")&&(solving||!started)){
            Card out=returnCard();
            if(out!=null)addObject(out,width/2,height/2);

        }
        if(timer.millisElapsed()>5000&&started&&!solving){
            solving=true;
            generate(64,difficulty,1);
        }
        if(timer.millisElapsed()>5000+10000&started&&solving){
            if(checkTrue()){
                isRight.setValue("True");
            }
            else isRight.setValue("False");
            started=false;
            solving=false;
        }

    }
}
