import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/**
 * Write a description of class StartWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartWorld extends World
{

    /**
     * Constructor for objects of class StartWorld.
     * 
     */
    static GreenfootImage[][] cardsImages=new GreenfootImage[13][4];//rank and suit
    static GreenfootImage[][] cardsImagesSmall=new GreenfootImage[13][4];//rank and suit
    static boolean initiated=false;
    Button button=new Button();
    toRankingBoard Torb=new toRankingBoard();
    Label player=new Label("Welcome",40);
    JFrame frame=new JFrame();

    public StartWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Game.width, Game.height, 1); 
        if(!initiated){
            initiated=true;
            initiateCards();
        }

        frame.setAlwaysOnTop(true); 
        addObject(button, getWidth()/2,50);
        addObject(Torb, getWidth()/4,50);
        addObject(player, getWidth()/2,getHeight()/2);

        Label Start=new Label("",6);
        prepare();
        Intofile.loadPlayers();

        // Login
        Label log = new Label("Login to save your score!", 40);
        log.setFillColor(Color.CYAN);
        log.setLineColor(Color.CYAN);
        addObject(log, getWidth()/2, getHeight()/2 - 170);

        // How to login
        Label log1 = new Label("Press 'g' for returning users", 30);
        log1.setFillColor(Color.PINK);
        log1.setLineColor(Color.PINK);
        addObject(log1, getWidth()/2, getHeight()/2 - 120);

        Label log2 = new Label("Press 'n' to create new login", 30);
        log2.setFillColor(Color.YELLOW);
        log2.setLineColor(Color.YELLOW);
        addObject(log2, getWidth()/2, getHeight()/2 - 70);

        // Are you ready?
        Label ready = new Label("Are you ready?", 50);
        ready.setFillColor(Color.MAGENTA);
        ready.setLineColor(Color.WHITE);
        addObject(ready, getWidth()/2, getHeight()/2 + 60);

    }

    GreenfootImage getCardImage(int rank,int suit){
        int imageNumber=suit*13+rank;
        String imageName=Integer.toString(imageNumber);
        if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);
        return new GreenfootImage("tile0"+imageName+".png");

    }

    public void initiateCards(){
        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                GreenfootImage k=getCardImage(rank,suit);
                k.scale(Card.length,Card.height);
                cardsImages[rank][suit]= k;
                //addObject(new Card(rank,suit),0,0);

            }
        }

    }

    private boolean isNumber(String str){

        for(int i=0; i<str.length(); i++)
            if(!Character.isDigit(str.charAt(i)))return false;
        return true;

    }


    public void act(){
        if(Intofile.currentPlaying!=null)
            player.setValue("Welcome\n"+Intofile.currentPlaying.name);

        if(Greenfoot.mouseClicked(button)){
            if(Intofile.currentPlaying!=null){
                String in= JOptionPane.showInputDialog("Enter the number of cards you want to remember");
                if(in!=null&&isNumber(in)){int cards=Integer.parseInt(in); Greenfoot.setWorld(new Game(cards,cards*5,cards*5000000));}

            }
            else{JOptionPane.showMessageDialog(frame,
                    "Enter username",
                    "User not found",
                    JOptionPane.PLAIN_MESSAGE);}
        }

        if(Greenfoot.mouseClicked(Torb)){
            Greenfoot.setWorld(new RankingBoard());
        }

        if(Greenfoot.isKeyDown("S")){

        }
        if(Greenfoot.isKeyDown("L")){

            Intofile.loadPlayers();
        }
        if(Greenfoot.isKeyDown("N")){
            Intofile.newPlayer();
        }
        if(Greenfoot.isKeyDown("G")){
            Intofile.getPlayer();
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
