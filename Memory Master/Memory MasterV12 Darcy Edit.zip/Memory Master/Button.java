import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Button extends ButtonTemp
{
    /**
     * To shrink the image
     */

    Button() 
    {
        //setImage(null);
        super(new GreenfootImage("StartButton.PNG"),new GreenfootImage("StartButtonInverted.png"),0.52);

    }

}
