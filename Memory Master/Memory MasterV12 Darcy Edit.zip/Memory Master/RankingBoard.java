import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RankingBoard extends World
{
    static Vector<Player>ranking=new Vector<Player>();
    Label k=new Label("",40);
    RankingBoard(){
        super(Game.width,Game.height,1);
        ranking.clear();
        String put="";
        for(String k:Intofile.NameToPlayer.keySet()){
            ranking.add(Intofile.NameToPlayer.get(k));
        }
        mergeSort(ranking);
        for(int ind=0;ind<Math.min(10,ranking.size()-1);ind++){
            Player y=ranking.get(ind);
            put=put+y.toString()+"\n";

        }
        k.setValue(put);
        addObject(k,getWidth()/2,getHeight()/2);
    }

    static void mergeSort(Vector<Player> arr){
        Vector<Player>aux=new Vector<Player>();
        for(int i=0; i<arr.size(); i++){
            aux.add(arr.get(i));
        }
        mergeSort(arr,aux,0,arr.size()-1);
    }

    static void mergeSort(Vector<Player> arr,Vector<Player> aux, int left,int right){
        if(left>=right)return;
        int mid=(left+right)/2;

        mergeSort(arr,aux,mid+1	,right);
        mergeSort(arr,aux,left,mid);

        merge(arr,aux,left,mid,right);

    }

    static void merge(Vector<Player>arr,Vector<Player>aux,int left,int mid,int right){
        for(int i=left; i<=right; i++){
            aux.set(i, arr.get(i));
        }
        int lo=left,hi=mid+1;
        for(int k=left; k<=right; k++){
            if(lo>mid){
                arr.set(k,aux.get(hi));
                hi++;
            }else if(hi>right){
                arr.set(k,aux.get(lo));
                lo++;
            }else if(Player.compair(aux.get(lo),aux.get(hi))){  
                arr.set(k,aux.get(lo));
                lo++;
            } else {  
                arr.set(k,aux.get(hi));
                hi++;
            }
        }
    }

}
