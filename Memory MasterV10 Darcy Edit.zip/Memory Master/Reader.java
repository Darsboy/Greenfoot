import java.util.*;
import java.io.InputStream;
/**
 * A reader for files that you want to use within a Greenfoot project.
 * Author(Darcy)
 * 4/11/2019
 */
public class Reader 
{
    /**
     * Opens a text file inside the package folder and returns a scanner to
     * read it. This works for text files inside jar files.
     * 
     * @param name The name of the text file
     * @return A Scanner object that is used to read the contents of the text   
     *  file.
     */
    public Scanner getScanner(String filename){
        InputStream myFile = getClass().getResourceAsStream(filename);
        if(myFile != null){
            return new Scanner(myFile);
        }
        return null;
    }

    /* 
     * Example use of the Reader in the constructor for MyWorld.
     * This will read all words in the nouns.txt file into an arraylist
     */
    public HashMap<String,Player> getTextInput(String fileName)
    {
        HashMap<String,Player> usernametoPlayer=new HashMap<String,Player>();

        Scanner input = getScanner(fileName);
        ArrayList<String> nounsList = new ArrayList<String>();
        while(true)
        {String s1="",s2="",s3="";
            if(input.hasNext())
                s1=input.nextLine();
            if(input.hasNext())
                s2=input.nextLine();
            if(input.hasNext())
                s3=input.nextLine();
            if(s1.length()==0||s2.length()==0||s3.length()==0)break;
            if(s1.equals("======="))return usernametoPlayer;
            String name=s1,password=s2;
            int score=Integer.parseInt(s3);

            usernametoPlayer.put(name,new Player(name,password,score));
        }
        return usernametoPlayer;
    }

}
