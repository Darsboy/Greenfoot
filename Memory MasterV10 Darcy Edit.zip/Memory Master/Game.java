import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Game extends greenfoot.World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    static int height=600,width=(int)(1.6*height);

    int topCard=50;
    CardSlot Clicked=new CardSlot(null);
    Card selectedCard=null;
    Vector<Card>cards=new Vector<Card>();//rank and suit

    HashMap<Card,Boolean>inserted=new HashMap<Card,Boolean>();
    Label numbers=new Label("",20);
    Label isRight=new Label("",20);
    Random rand=new Random();
    boolean pass=false;
    int difficulty;
    List<CardSlot> slots=new LinkedList<CardSlot>();
    SimpleTimer timer=new SimpleTimer();

    Label countDown=new Label("Count Down:",20);

    Button button=new Button();
    CardSlot testSlot=new CardSlot(new Card(0,0));
    int lookingTime,solvingTime;
    int imagelength=StartWorld.cardsImages[0][0].getWidth()+5;
    int imageHeight=StartWorld.cardsImages[0][0].getHeight()+5;
    public Game(int difficulty,int lt,int st)
    {   
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(width, height, 1); 
        this.difficulty=difficulty;
        lookingTime=lt;
        solvingTime=st;
        shuffleCards(cards);
        addObject(button, getWidth()/2,getHeight()-200);
        addObject(numbers,getWidth()/2,height-40);
        addObject(isRight,getWidth()/2,height-80);
        //addObject(testSlot,getWidth()/4,getHeight()/2);
        addObject(countDown,getWidth()-getWidth()/8,10);

    }

    public void generate(int start, int amuont,int typ){
        if(typ==0){
            for(int i=0; i<amuont; i+=1){
                int x=(i*imagelength)%(13*imagelength)+start, y=topCard+imageHeight*((i)/(13));
                slots.add(new CardSlot(cards.get(i)));
                addObject(cards.get(i),x,y);

            }
        }
        if(typ==1){
            removeCards();

            for(int rank=0; rank<13; rank++){
                //for(int suit=0;suit<4;suit++){

                Card place=new Card(rank,0);
                GreenfootImage newimg= place.getImage();

                //newimg.scale(30,48);
                place.setImage(newimg);
                addObject(place,rank*(newimg.getWidth()+5)+64,300);

                // }
            }

            for(int i=0; i<amuont; i+=1){
                int x=(i*imagelength)%(13*imagelength)+start, y=topCard+imageHeight*(i/(13));
                addObject(slots.get(i),x,y);
            }

        }
    }

    public void cheat(){
        for(CardSlot k:slots){
            /*
            Card occupie=null;
            Card needed=null;
             */
            k.occupie=k.needed;

        }
    }

    public void removeCards(){
        List remove = getObjects( Card.class );

        if (remove != null) { removeObjects(remove); }
    }

    public Card  returnCard(){
        Object[] possibleValues = { "Ace", "2", "3","4","5","6","7","8","9","10","Jack","Queen","King" };
        HashMap<Object,Integer> mapInd = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValues.length;i++){
            mapInd.put(possibleValues[i],i);

        }
        Object selectedValue = JOptionPane.showInputDialog(null,"Choose rank", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValues, possibleValues[0]);
        if(selectedValue==null)return null;
        Object[] possibleValuesSuit = {"Clovers","Heart","Spade","Diamond"};
        Object selectedValueSuit = JOptionPane.showInputDialog(null,"Choose rank", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValuesSuit, possibleValuesSuit[0]);
        if(selectedValue==null||selectedValueSuit==null)return null;
        HashMap<Object,Integer> mapIndSuit = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValuesSuit.length;i++){
            mapIndSuit.put(possibleValuesSuit[i],i);

        }
        //System.out.println(selectedValue+" "+selectedValueSuit);
        if(selectedValue==null||selectedValueSuit==null)return null;

        numbers.setValue(mapInd.get(selectedValue)+" "+mapIndSuit.get(selectedValueSuit));
        return new Card(mapInd.get(selectedValue),mapIndSuit.get(selectedValueSuit));

        //return new Card(mapInd.get(selectedValue),mapIndSuit.get(possibleValuesSuit));
    }
    
    int oldrank=-1;
    Card[] Show=new Card[4];
    public void show(){

        for(int rank=0; rank<13; rank++){
            if(selectedCard!=null&&selectedCard.rank==rank&&rank!=oldrank){
                oldrank=rank;
                for(int suit=1; suit<4; suit++){
                    removeObject(Show[suit]);  
                }
                for(int suit=1; suit<4; suit++){

                    Card place=new Card(selectedCard.rank,suit);
                    GreenfootImage newimg= place.getImage();

                    Show[suit]=place;  
                    //suit
                    addObject(place,selectedCard.rank*(newimg.getWidth()+5)+64,300+suit*(newimg.getHeight()+5));
                    //addObject(place,selectedCard.rank*(newimg.getWidth()+5)+64 ,90);
                }

            }else if(selectedCard==null){
                for(int suit=1; suit<4; suit++){
                    removeObject(Show[suit]);  
                }
            }
        }
    }

    public void shuffleCards(List<Card>cards){
        cards.clear();
        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                int imageNumber=suit*13+rank;
                String imageName=Integer.toString(imageNumber);
                if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);

                cards.add(new Card(rank,suit));
                //addObject(new Card(rank,suit),0,0);

            }
        }
        for(int i=0; i<cards.size(); i++){
            int randomIndex = rand.nextInt(52);
            Card x = cards.get(i);
            Card y =  cards.get(randomIndex);

            cards.set(i, y);
            cards.set(randomIndex, x);
        }
    }

    private boolean checkTrue(){
        boolean ret=true;
        int i=0;
        for(CardSlot k:slots){
            ret=ret&&k.isRight();
            int x=(i*imagelength)%(13*imagelength)+leftBorder, y=topCard+imageHeight*((i)/(13));
            i++;
            addObject(k.needed, x,y+imageHeight);
        }
        return ret;
    } 
    boolean solving =false,started=false;
    int ithCard=0,leftBorder=64;
    int lookElapsed=0,solveElapsed=0;
    SimpleTimer second=new SimpleTimer();
    public void act(){
        // press start
        show();

        if(selectedCard!=null&&Clicked!=null){
            Clicked.occupie=selectedCard;
            Clicked=null;
            selectedCard=null;
        }

        if(Greenfoot.mouseClicked(button)&&!started){
            // see time start of looking phase
            started=true;
            timer.mark();
            removeCards();
            generate(leftBorder,difficulty,0);
            ithCard=0;
            lookElapsed++;
            second.mark();

        }

        if(started&&!solving){
            
            
            countDown.setValue("Count Down:"+(lookingTime-timer.millisElapsed())/1000);
            lookElapsed++;
            second.mark();
        }else
        if(started&&solving){
            
            int endInterval=lookingTime+solvingTime;
            countDown.setValue("Count Down:"+(endInterval-timer.millisElapsed())/1000);
            solveElapsed++;
            second.mark();
        }

        // new card
        if(Greenfoot.isKeyDown("space")&&(solving||!started)){
            int x=(ithCard*imagelength)%(13*imagelength)+leftBorder, y=topCard+imageHeight*(ithCard/(13));
            Card out=returnCard();
            if(out!=null){addObject(out,x,y);ithCard++;}
        }
        if(Greenfoot.isKeyDown("C")&&(solving||!started)){
            /*
            int x=(ithCard*imagelength)%(10*imagelength)+leftBorder, y=topCard+imageHeight*(ithCard/(10));
            Card out=returnCard();
            if(out!=null){addObject(out,x,y);ithCard++;}
             */

            cheat();
        }
        if(timer.millisElapsed()>lookingTime&&started&&!solving){
            // solveing phase
            solving=true;
            CardSlot forImg=new CardSlot(null);
            
            generate(leftBorder,difficulty,1);
            Clicked=null;
            selectedCard=null;
            second.mark();

        }

        if(timer.millisElapsed()>lookingTime+solvingTime&&started&&solving){
            // end of the game
            removeCards();
            if(checkTrue()){
                isRight.setValue("True");
            }
            else isRight.setValue("False");
            //started=false;
            //solving=false;
            if(Greenfoot.mouseClicked(button)){
                Greenfoot.setWorld(new StartWorld());
            }
            /*
            List remove = getObjects( Card.class );
            if (remove != null) { removeObjects(remove); }
             */
        }

    }
}
