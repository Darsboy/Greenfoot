
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instructions here.
 * 
 * @author (Mercedes) 
 * @version (a version number or a date)
 */
public class Instructions extends World
{

    /**
     * Constructor for objects of class Instructions.
     * 
     */
    
    Label ln6 = new Label("<<Press "+Startscreen.cont+" to start>>", 30);
    public Instructions()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
    
        super( Myworld.length, Myworld.height,1);
        Label ln1 = new Label("Type in the words that appear on the screen", 40);
        ln1.setFillColor(Color.GREEN);
        ln1.setLineColor(Color.GREEN);
        addObject(ln1, getWidth()/2, getHeight()/2 - 200);
        
        Label ln2 = new Label("The rockets will destroy the words it touches", 40);
        ln2.setFillColor(Color.YELLOW);
        ln2.setLineColor(Color.YELLOW);
        addObject(ln2, getWidth()/2, getHeight()/2 - 100);
        
        Label ln3 = new Label("Earn a high score by typing as many words as you can", 40);
        ln3.setFillColor(Color.WHITE);
        ln3.setLineColor(Color.WHITE);
        addObject(ln3, getWidth()/2, getHeight()/2);
        
        Label ln4 = new Label("Don't let the word touch the right side or else you'll lose!", 40);
        ln4.setFillColor(Color.MAGENTA);
        ln4.setLineColor(Color.MAGENTA);
        addObject(ln4, getWidth()/2, getHeight()/2 + 100);
        
        Label ln5 = new Label("Good luck!", 40);
        ln5.setFillColor(Color.PINK);
        ln5.setLineColor(Color.PINK);
        addObject(ln5, getWidth()/2, getHeight()/2 + 200);
        
        
        ln6.setFillColor(Color.WHITE);
        ln6.setLineColor(Color.WHITE);
        addObject(ln6, getWidth()/2 + 350, getHeight()/2 + 250);
    }
    public void act()
    {
       // if(Greenfoot.mouseClicked(ln6)){
           if(Greenfoot.isKeyDown(Startscreen.cont)){
            Greenfoot.setWorld(new Myworld());
        }
    }
}

