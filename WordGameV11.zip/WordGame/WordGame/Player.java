import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class character here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Label
{
    /**
     * Act - do whatever the character wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    String playerName;
    int score;
    Player(String name, int value,int fontsize){
        super("Player: "+name+" Score: "+Integer.toString(value),fontsize);
    }    
}
