import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class endscree here.
 * 
 * @author (Mercedes) 
 * @version (a version number or a date)
 */
public class Startscreen extends World
{

    /**
     * Constructor for objects of class endscree.
     * 
     */
    static String cont="S"; 
    Label subtitle = new Label("<<Press "+cont+" to start>>", 60);
    public Startscreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super( Myworld.length, Myworld.height,1);
        
        // Game Title
        Label title = new Label("Type Shooter", 90);
        title.setFillColor(Color.WHITE);
        title.setLineColor(Color.WHITE);
        addObject(title, getWidth()/2, getHeight()/2 - 50);

        // Subtitle
       
        subtitle.setFillColor(Color.GREEN);
        subtitle.setLineColor(Color.GREEN);
        addObject(subtitle, getWidth()/2, getHeight()/2 + 130);
    }
    public void act()
    {      
        //  if(Greenfoot.mouseClicked(ln6)){
        
        if(Greenfoot.isKeyDown(cont)){
            Greenfoot.setWorld(new Instructions());
        }
    }
}

