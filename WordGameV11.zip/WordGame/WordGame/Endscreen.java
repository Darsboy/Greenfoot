//Finalized end screen
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*; 
import java.lang.*; 
import java.io.*; 
/**
 * Write a description of class endscreen here.
 * 
 * @author (Mercedes) 
 * @version (April 2019)
 */
public class Endscreen extends World
{

    /**
     * Constructor for objects of class endscreen.
     * 
     */

    public static LinkedList<Player> scoreBoard=new LinkedList<Player>();
    public Endscreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Myworld.length, Myworld.height, 1); 
       
        Label ln1 = new Label("GAME OVER", 100);
        ln1.setFillColor(Color.GREEN);
        ln1.setLineColor(Color.GREEN);
        addObject(ln1, getWidth()/2, getHeight()/2 - 200);
        
        Label finalScore = new Label("Your Score: ", 70);
        finalScore.setFillColor(Color.YELLOW);
        addObject(finalScore, getWidth()/2, getHeight()/2 - 60);
        addObject(scoreBoard.get(0),getWidth()/2,getHeight()/2 - 20);
        
        Label recentScores = new Label("Recent Scores: ", 50);
        recentScores.setFillColor(Color.WHITE);
        addObject(recentScores, getWidth()/2, getHeight()/2 + 40);
        
        Label playAgain = new Label("Play Again?", 60);
        playAgain.setFillColor(Color.MAGENTA);
        addObject(playAgain, getWidth()/2, getHeight()/2 + 200);
        
        Label pressSpace = new Label("<<Press space>>", 40);
        pressSpace.setFillColor(Color.PINK);
        addObject(pressSpace, getWidth()/2, getHeight()/2 + 260);
        
        for(int i1=1; i1<Math.min(6,scoreBoard.size()); i1++){
            int i=i1-1;
            addObject(scoreBoard.get(i1),Myworld.length/2,i*20+getHeight()/2 + 80);
        }
    }
    void addScore(Player add){
        scoreBoard.add(add);
    }
    class SortbyScore implements Comparator<Player> 
    { 
        // Used for sorting in ascending order of 
        // roll name 
        public int compare(Player a, Player b) 
        { 
            return (a.score-b.score); 
        } 
    } 
  
    public void act()
    {
        if(Greenfoot.isKeyDown("space")){
            Greenfoot.setWorld(new Myworld());
        }
    }
}


