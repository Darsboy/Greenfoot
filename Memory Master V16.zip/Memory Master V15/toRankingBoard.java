import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class toRankingBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class toRankingBoard extends ButtonTemp
{
    /**
     * Act - do whatever the toRankingBoard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    toRankingBoard(){
        super(new GreenfootImage("tile000.png"),new GreenfootImage("tile000.png"),0.5);
    }  

    public void act() 
    {
    }
}
