import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.HashMap;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends greenfoot.World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    static int height=400,width=(int)(1.6*height);
    static GreenfootImage[][] cards=new GreenfootImage[13][4];//rank and suit
    public MyWorld()
    {   
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(width, height, 1); 

        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                int imageNumber=rank*4+suit;
                String imageName=Integer.toString(imageNumber);
                if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);

                cards[rank][suit]=new GreenfootImage("tile0"+imageName+".png");
            }
        }
        addObject(new CardSlot(new Card(0,1)),getWidth()/2,getHeight()/2);
        addObject(new Card(0,1),0,0);
        //addObject(returnCard(),width/2,height/2);
    }

    public static Card  returnCard(){
        Object[] possibleValues = { "Ace", "2", "3","4","5","6","7","8","9","Jack","Queen","King" };
        HashMap<Object,Integer> mapInd = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValues.length;i++){
            mapInd.put(possibleValues[i],i);

        }
        Object rank = JOptionPane.showInputDialog(null,"Choose rank", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValues, possibleValues[0]);

        Object[] possibleValuesSuit = {"Clovers","Heart","Spade","Diamond"};
        HashMap<Object,Integer> mapIndSuit = new HashMap<Object,Integer>();
        for(int i=0; i<possibleValuesSuit.length;i++){
            mapIndSuit.put(possibleValuesSuit[i],i);

        }
        Object Suit = JOptionPane.showInputDialog(null,"Choose suit", "Input",JOptionPane.INFORMATION_MESSAGE, null,possibleValuesSuit, possibleValuesSuit[0]);
        if(rank==null||Suit==null)return null;
        //return new Card(0,0);
        return new Card(mapInd.get(rank),mapIndSuit.get(Suit));
    }

    public void act(){
        if(Greenfoot.isKeyDown("space")){
            Card add=returnCard();
            if(add!=null)
            addObject(add,width/2,height/2);
        }
    }
}
