import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int speed;
    Word target;
    Bullet(Word targ){
            target=targ;
            speed=2;
            GreenfootImage image = getImage();
            image.scale(image.getWidth()/2, image.getHeight() /2);
            setImage(image);
    }
    public void act() 
    {
        
        Myworld in=(Myworld)getWorld();
        //speed+=in.wordSpeed;
        speed+=1;
        if (target.getWorld() != null)
            turnTowards(target.getX(),target.getY());
        
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) *speed );
        int y = (int) Math.round(getY() + Math.sin(angle) *speed);
        setLocation(x, y);
        Word inter=(Word)getOneIntersectingObject(Word.class);
        Actor interBul=getOneIntersectingObject(Bullet.class);
        
        if(getX()>=in.getWidth()-1||getX()<=1||getY()<=1||getY()>=in.getHeight()-1)in.removeObject(this);

        if(inter!=null){
        //&&!in.queueShow.isEmpty()&&inter==in.queueShow.peek()){
            in.score.add(inter.getValue().length());
            in.removeObject(inter);
            in.removeWord(inter);
            in.queueShow.dequeue();
            //in.removeObject(this);
        } 
    }   
}
