
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.lang.System;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (Darcy Liu) 
 * @version (4/5/2019)
 */
public class Myworld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public int wordSpeed;
    private int arr=0;
    public static int height=675,length=(int)(1.6*height);
    Label inWord=new Label("",35);
    Label firstWord=new Label("",35);
    Label difficulty=new Label("",35);
    MyQueue<Word> wsQueue=new MyQueue<Word>();
    MyQueue<Word> queueShow=new MyQueue<Word>();
    SimpleTimer st =new SimpleTimer();
    int hardness;
    LinkedList<Turret> turretArray=new LinkedList<Turret>();

    public HashMap<String,Word>wordMap=new HashMap<String,Word>();

    ArrayList<String>[] wordList = new ArrayList[3];
    private int turretNumber=0;
    HashMap<Integer,ArrayList<String>> di=new HashMap<Integer,ArrayList<String>> ();
    HealthBar healthBar = new HealthBar();
    int maxLength=0;
    Counter score=new Counter();
    public Myworld()
    {    
        // Create a new world with length X height cells with a cell size of 1x1 pixels.
        super(length, height, 1);   
        hardness=0;
        Reader readWordstxt=new Reader();
        // wordList[0]=readWordstxt.getTextInput("W-Nouns.txt");
        //wordList[1]=readWordstxt.getTextInput("W-Adjictives.txt");
        //wordList[2]=readWordstxt.getTextInput("W-Verbs.txt");
        addObject(score,length-length/8,20);
        addObject(healthBar, 840, 20);
        inMapOfWordsdi(readWordstxt.getTextInput("W-Nouns.txt"));
        inMapOfWordsdi(readWordstxt.getTextInput("W-Adjictives.txt"));
        inMapOfWordsdi(readWordstxt.getTextInput("W-Verbs.txt"));

        addObject(inWord,length/8,20);
        addObject(firstWord,length/8,height-20);
        addObject(difficulty,length-length/8,height-20);
        //addObject(new Turret(),300,400-64);
        //fillStack();
        Turret test=new Turret();
        turretNumber=putTurretsCircle(height/2);
        //putTurretsSinusoidal();

        
        if(wordMap.keySet().isEmpty()){
            d="";
            fww="";  
            Word f=randomWord("");
            addObject(f,0,height/2);
            wordMap.put(f.getValue().trim(),f);
            queueShow.enqueue(f);
        }
    }

    public HealthBar getHealthBar()
    {
        return healthBar;
    }

    public void endGame()
    {
        //gameOver.addScore(new Player("Darcy",score.getValue(),10));
        Greenfoot.setWorld(new TextBox(score.getValue()));
    }

    private void inMapOfWordsdi(ArrayList<String> h){

        for(int i=0; i<h.size();i++){
            String cur=h.get(i).trim();
            if(cur.length()==0)continue;
            maxLength=Math.max(maxLength,cur.length());
            if(di.containsKey(cur.length())){
                di.get(cur.length()).add(cur);
            }else{
                di.put(cur.length(),new ArrayList<String>());
                di.get(cur.length()).add(cur);
            }   
        }

    }

    private void putTurrets(){
        for(int i=64; i<length; i+=64){
            Turret k=new Turret(); 
            Turret k1=new Turret(); 
            turretArray.push(k);
            turretArray.push(k1);
            addObject(k,i,64);
            addObject(k1,i,400-64);
        }

    } 

    /***

    The put turrets method to put six turrets in a circle around the map
     */
    private int putTurretsCircle(int r){
        int turrets=0;
        int xCenter=length/2;
        int yCenter=height/2;
        //y=sqrt(r^2-(x-a)^2)+b;
        for(int x=0; x<length; x++){
            if(x%256==0&&r*r-(x-xCenter)*(x-xCenter)>=0){
                Turret k=new Turret(); 
                Turret k1=new Turret(); 
                turrets++;
                int y1=(int)(Math.sqrt(r*r-(x-xCenter)*(x-xCenter))+yCenter),y2=(int)(-Math.sqrt(r*r-(x-xCenter)*(x-xCenter))+yCenter);
                turretArray.push(k);
                turretArray.push(k1);
                addObject(k,x,y1);
                //y=sqrt(r*r-x*x)
                addObject(k1,x,y2);
                // addObject(k,x,-y1);
            }

        }
        return turrets;
    }

    private void putTurretsSinusoidal(){
        int xCenter=length/2;
        int yCenter=height/2;
        //y=sqrt(r^2-(x-a)^2)+b;
        for(int x=0; x<length; x++){
            if(x%128==0){
                Turret k=new Turret(); 
                Turret k1=new Turret(); 

                int y1=(int)(100*Math.sin((2*Math.PI/128)*x)+yCenter); turretArray.push(k);

                addObject(k,x,y1);
                //y=sqrt(r*r-x*x)
            }
            // addObject(k,x,-y1);

        }
    }

    private void fillStack(){
        wsQueue.enqueue(new Word("Type ",50,1));
        wsQueue.enqueue(new Word("in ",50,1));
        wsQueue.enqueue(new Word("the ",50,1));
        wsQueue.enqueue(new Word("respective ",50,1));
        wsQueue.enqueue(new Word("word ",50,1));
    }

    /***
    Enqueue a random word
     */
    public Word randomWord(String d){
        /*
        ;

        for(int i=0; i<length; i++){
        d=d+(char)getRandomNumber('a','z');

        }
         */

        int wordLength=Math.max((int)(Math.log(2+hardness)/Math.log(5)),2);
        wordSpeed=Math.max(maxLength*hardness/(wordLength),1);
        difficulty.setValue("Difficulty "+(Integer.toString(wordSpeed)));
        if(wordLength>0&&di.containsKey(wordLength))
            d=di.get(wordLength).get(getRandomNumber(0,di.get(wordLength).size()-1));
        //d=wordList[arr].get(getRandomNumber(0,wordList[arr].size()-1));
        //arr=(arr+1)%3;

        int r=getRandomNumber(0,255),g=getRandomNumber(0,255),b=getRandomNumber(0,255);
        Color wordc=new Color(r,g,b);  
        Color wordf=new Color(255-r,255-g,255-b);

        Word inw=new Word(d,50,wordSpeed);
        inw.setLineColor(wordc);
        inw.setFillColor(wordf);
        
        //wsQueue.enqueue(inw);
        return inw;
        
    }

    private void stringToQueue(String s){
        int start=0;
        for(int i=0; i<s.length(); i++){
            if(s.charAt(i)==' '){
                int r=getRandomNumber(0,255),g=getRandomNumber(0,255),b=getRandomNumber(0,255);
                Color wordc=new Color(r,g,b);  
                Color wordf=new Color(255-r,255-g,255-b);
                Word inw=new Word(s.substring(start,i),50,6/(i-start+1));
                inw.setLineColor(wordc);
                inw.setFillColor(wordf);
                queueShow.enqueue(inw);
                start=i+1;
            }
        }
        queueShow.enqueue(new Word(s.substring(start,s.length()),50,6/(s.length()-start+1)));
    }

    public int getRandomNumber(int start,int end)
    {
        int normal = Greenfoot.getRandomNumber(end-start+1);
        return normal+start;
    }
    String d="",fww="";
    int delay=0;
    Word faceing;

    public void removeWord(Word wr){
        wordMap.remove(wr.getValue());
    }

    public void act(){
        inWord.setValue(d);

        firstWord.setValue("Type: "+fww);
        if(!queueShow.isEmpty())fww=queueShow.peek().getValue();
        hardness++;

        String in=Greenfoot.getKey();
        if(in!=null&&!in.equals("enter")){
            if(in.equals("space")){
                d=d+" ";
            }
            if(d.length()>0&&in.equals("backspace")){
                d=d.substring(0,d.length()-1);
            }
            else if(in.length()==1)
                d=d+in;
        }
        if(wordMap.containsKey(d)){
            Turret.set(wordMap.get(d).getX()+wordMap.get(d).getValue().length()*10,wordMap.get(d).getY());
            inWord.setFillColor(Color.GREEN);
            inWord.setValue("Target Locked: "+wordMap.get(d).getValue());
        }
        if(Greenfoot.isKeyDown("enter")){
            int r=getRandomNumber(0,255),g=getRandomNumber(0,255),b=getRandomNumber(0,255);
            Color wordc=new Color(r,g,b);  
            Color wordf=new Color(255-r,255-g,255-b);
            //Word inw=new Word(d,50);
            //inw.setLineColor(wordc);
            //inw.setFillColor(wordf);
            // check identicality to remove queue first
            // pop the remove queue and remove the object
            //queue.push(inw);
            //if(!queueShow.isEmpty()&&queueShow.peek().getValue().equalsIgnoreCase(d))
            d=d.trim();
            if(wordMap.containsKey(d)){
                //Word k=queueShow.dequeue();

                //removeObject(k);
                score.add(d.length());
                hardness++;
                //boolean fired=false;
                for(int i=0; i<turretArray.size();i++){
                    // if(!fired&&getRandomNumber(0,turretNumber)==0)
                    //turretArray.get(getRandomNumber(0,turretNumber-1)).fire();
                    //turretArray.get(getRandomNumber(0,turretNumber-1)).fire();
                    // fired=true;
                    turretArray.get(i).fire(wordMap.get(d));
                }
                //if(!fired)turretArray.get(turretArray.length()-1).fire();
                //Turret.set(k.getX(),k.getY());

            }
            inWord.setFillColor(Color.WHITE);
            d="";
        }
        if(wordMap.keySet().isEmpty()){
            d="";
            fww="";  
            Word f=randomWord("");

            delay=f.getSpeed()*f.getValue().length();

            if(!wordMap.containsKey(f.getValue())&&st.millisElapsed() > delay &&f.getValue().length()>0){

                addObject(f,0,height/2);
                wordMap.put(f.getValue().trim(),f);
                queueShow.enqueue(f);

                st.mark(); // Reset the timer
            }
        }


    }
}
