import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Turret here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Turret extends Actor
{
    /**
     * Act - do whatever the Turret wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private static int x,y;
    public static void set(int x1,int y1){
        x=x1;
        y=y1;
    }

    Turret(){
        GreenfootImage image = getImage();
        image.scale(image.getWidth() /2, image.getHeight() /2);
        setImage(image);
    }

    public void fire(Word target){
        Bullet bullet=new Bullet( target);
        getWorld().addObject(bullet, getX(), getY());
        bullet.setRotation(getRotation());

    }
    public int getRandomNumber(int start,int end)
    {
        int normal = Greenfoot.getRandomNumber(end-start+1);
        return normal+start;
    }
    public void act() 
    {   
        turnTowards(x,y);
        double angle = Math.toRadians( getRotation() );
        int bulletx = (int) Math.round(getX() + Math.cos(angle) * 10);
        int bullety = (int) Math.round(getY() + Math.sin(angle) * 10);
        
    }    
}
