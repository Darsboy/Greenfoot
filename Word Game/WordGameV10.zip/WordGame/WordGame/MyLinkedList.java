import java.util.Iterator;

public class MyLinkedList<E> implements Iterable<E> 
{
    private Node first,last;
    int length=0;
    private class Node {
        private E item;
        private Node next;
    }

    public boolean isEmpty() {
        return first == null;
    }

    public void push(E item) {
        length++;
        Node oldLast=last;
        last=new Node();
        last.next=null;
        last.item=item;
        if(isEmpty()){
            first=last;
        }else{
            oldLast.next=last;
        }
        /*
        Node oldLast=last;
        last=new Node();
        last.item=item;
        last.next=null;
        if(isEmpty()){
        first=last;
        }else{
        oldLast.next=last;
        }
         */

    }

    private Node obtain(int start,int dest,Node cur){
        if(start==dest)return cur;
        return obtain(start+1,dest,cur.next);
    }

    public int length(){
        return length;
    }

    public E get(int ind){
        return obtain(0,ind,first).item;
    }
/*
    private void findRemove(Node cur,E find){
        if(cur.next.item==find){
            cur=cur.next.next;
        }else findRemove(cur.next,find);
    }

    public void remove(E stuff){
        findRemove(first,stuff);
    }
*/
    public E pop() {
        length--;
        E item = first.item;
        first = first.next;
        return item;
    }

    public E peek() {
        return first.item;
    }

    // To make this data structure work with for-each loops
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator<E> {

        private Node n = first;

        public boolean hasNext() {
            return n != null;
        }

        public E next() {
            E item = n.item;
            n = n.next;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
