import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Word extends Label
{
    private String value;
    private int fontSize;
    private Color lineColor = Color.BLACK;
    private Color fillColor = Color.WHITE;

    private static final Color transparent = new Color(0,0,0,0);

    int speed;
    /**
     * Create a new label, initialise it with the int value to be shown and the font size 
     */
    public Word(int value, int fontSize,int speed)
    {
        super(value,fontSize);
        this.speed=speed;
        //this(Integer.toString(value), fontSize,speed);

    }

    public Word(String value, int fontSize,int speed)
    {
        super(value,fontSize);
        this.speed=speed;
    }

    public int getSpeed(){
        return speed;
    }
    /**
     * Sets the value  as text
     * 
     * @param value the text to be show
     */

    public void act() 
    {
        Myworld in=(Myworld)getWorld();
        setLocation(getX()+speed,getY());

        if(getX()>=getWorld().getWidth()-1){
            in.randomWord("");
            in.queueShow.dequeue();

            in.removeWord(this);

            HealthBar healthBar = in.getHealthBar();
            healthBar.loseHealth(25);
            if(healthBar.health <= 0)
            {
                in.endGame();
            }

            //in.wordMap.remove(value);
            in.removeObject(this);

        }
    }    
}