import java.util.Iterator;

public class MyQueue<E> implements Iterable<E>
{
    private Node first,last;
    int size1=0;
    private class Node {
        private E item;
        private Node next;
    }

    public boolean isEmpty() {
        return first == null;
    }
    public int size() {
        return size1;
    }
    public void enqueue(E item) {
        size1++;
        Node oldLast=last;
        last=new Node();
        last.item=item;
        last.next=null;
        if(isEmpty()){
            first=last;
        }else{
            oldLast.next=last;
        }
    }

    public E dequeue() {
        size1--;
        E item = first.item;
        first = first.next;
        return item;
    }

    public E peek() {
        return first.item;
    }

    // To make this data structure work with for-each loops
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator<E> {

        private Node n = first;

        public boolean hasNext() {
            return n != null;
        }

        public E next() {
            E item = n.item;
            n = n.next;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
