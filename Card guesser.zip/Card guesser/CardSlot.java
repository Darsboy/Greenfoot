import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CardSlot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CardSlot extends Actor
{
    /**
     * Act - do whatever the CardSlot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Card occupie=null;
    Card needed=null;

    CardSlot(Card n)
    {
        needed=n;

    }

    boolean isRight(){
        if(needed==null||occupie==null)return false;
        return needed.equals(occupie);
    }

    /*
    public void act() 
    {
    Card touching= (Card)getOneIntersectingObject(Card.class);
    if(touching!=null&&touching.isDragged()==false){
    occupie=touching;
    touching.setLocation(getX(),getY());
    }else if (touching==null){
    occupie=null;

    }
    }  
     */
    public void act(){
        Game world=(Game)getWorld();
        if (Greenfoot.mouseClicked(this)&&world!=null) {
            world.Clicked=this;
        }
        if(occupie!=null){
            setImage(occupie.getImage());

        }
    }
}
