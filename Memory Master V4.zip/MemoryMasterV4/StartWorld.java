import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class StartWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartWorld extends World
{

    /**
     * Constructor for objects of class StartWorld.
     * 
     */
    static GreenfootImage[][] cardsImages=new GreenfootImage[13][4];//rank and suit
    Button button=new Button();
    public StartWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Game.width, Game.height, 1); 
        initiateCards();
        addObject(button, getWidth()/2,50);
        Label Start=new Label("",6);
    }

    public void initiateCards(){

        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                int imageNumber=suit*13+rank;
                String imageName=Integer.toString(imageNumber);
                if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);
                cardsImages[rank][suit]=new GreenfootImage("tile0"+imageName+".png");
                //addObject(new Card(rank,suit),0,0);

            }
        }

    }

    public void act(){
        if(Greenfoot.mouseClicked(button)){
            Greenfoot.setWorld(new Game(5,10000,20000));
        }

    }
}
