
/**
 * Write a description of class DragonCurve here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Turtle
{
    // instance variables - replace the example below with your own
    private double x=0,y=0,angle=45;
    //angle is in degrees
    /**
     * Constructor for objects of class DragonCurve
     */
    double getX(){return x;}
    double getY(){return x;}
    Turtle(double xs,double ys,double angles){
        x=xs;
        y=ys;
        angle=angles;
    }
    public void drawLine(double Length){
        double angleOig=Math.toRadians(angle);
        // angle Oig is in degrees
        double x1=Length*Math.cos(angleOig)+x;
        double y1=Length*Math.sin(angleOig)+y;
        StdDraw.line(x,y,x1, y1);
        x=x1;
        y=y1;
    }

    public void turn(double angley){
        angle+=angley;
    }
/*

*/
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
}


