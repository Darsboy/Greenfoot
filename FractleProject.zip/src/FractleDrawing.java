import java.awt.Color;
public class FractleDrawing {
	/**
    Create a method to draw recursive Tree.
    Modify the code to personalize your tree.
    Add colour, re-size, change angles, add branches as you desire.
	 */

	/**
	 * Base code for drawing a fractal tree
	 */
	int [] arre={1,2,3,1,6};
	static Color [] arr={StdDraw.BLACK, StdDraw.BLUE, StdDraw.CYAN, StdDraw.DARK_GRAY, StdDraw.GRAY, StdDraw.GREEN, StdDraw.LIGHT_GRAY, StdDraw.MAGENTA, StdDraw.ORANGE, StdDraw.PINK, StdDraw.RED, StdDraw.WHITE, StdDraw.YELLOW};
	/**
	 * there is no method that directly makes a triangle in stdDraw so I made my own
	 * @param xc
	 * @param yc
	 * @param fractalSize
	 * @param angleOig
	 */
	private static void drawTriangle(double xc,double yc,double fractalSize,double angleOig){

		double angle1=angleOig+120,angle2=angle1+120;
		angleOig=Math.toRadians(angleOig);
		angle1=Math.toRadians(angle1);
		angle2=Math.toRadians(angle2);
		double xs[]={xc+fractalSize*Math.cos((angleOig)),xc+fractalSize*Math.cos(angle1),xc+fractalSize*Math.cos(angle2)};
		double ys[]={yc+fractalSize*Math.sin((angleOig)),yc+fractalSize*Math.sin(angle1),yc+fractalSize*Math.sin(angle2)};
		StdDraw.polygon(xs, ys);

	}
	/**
	 * @param order-the degree
	 * @param xc-the center of the TrianglesFractle
	 * @param yc-the center of the TrianglesFractle
	 * @param angle the angle which the TrianglesFractle are orietated
	 * @param fractalSize the radius
	 */
	private static void TrianglesFractle(int order,double xc,double yc,double Length,double angleOig){
		double coeff=2;

		drawTriangle(xc,yc,Length,angleOig);
		
		
		setCoulor(xc,yc);
		if(order==0)return;
		double distance=Length/2+Length/coeff;
		double newx,newy,angle;

		angle=Math.toRadians(angleOig+60);
		newx=xc+Math.cos(angle)*distance;
		newy=yc+Math.sin(angle)*distance;
		TrianglesFractle(order-1,newx,newy,Length/coeff,angleOig);

		angle=Math.toRadians(angleOig+60*3);
		newx=xc+Math.cos(angle)*distance;
		newy=yc+Math.sin(angle)*distance;
		TrianglesFractle(order-1,newx,newy,Length/coeff,angleOig);

		angle=Math.toRadians(angleOig+60*5);
		newx=xc+Math.cos(angle)*distance;
		newy=yc+Math.sin(angle)*distance;
		TrianglesFractle(order-1,newx,newy,Length/coeff,angleOig);
	}

	public static void setCoulor(double x,double y){
		int red=Math.max(0,(int) ((x-y)*255)),green=(int) ((1.0-x)*255),blue=(int) ((x*y)*255);
		StdDraw.setPenColor(red,green,blue);
	}
	/**
	 * @param order-the degree
	 * @param xc-the center of the tri-dragons
	 * @param yc-the center of the tri-dragons
	 * @param angle the angle which the dragons are orietated
	 * @param fractalSize the radius
	 */
	public static void drawDragon(int order,double xc,double yc,double angle,double fractalSize){
		setCoulor(xc,yc);
		DragonCurve c1=new DragonCurve(xc,yc,angle-60,order,fractalSize/8);
		setCoulor(xc,yc);
		DragonCurve c2=new DragonCurve(xc,yc,angle+60,order,fractalSize/8);
		setCoulor(xc,yc);
		DragonCurve c3=new DragonCurve(xc,yc,angle+180,order,fractalSize/8);

	}
	/**
	 * 
	 * Draw the fractal for every triangle drawn that is not the first draw 3 other triangles 
	 * and position them on the edges of the current triangle
	 * takes in the step number, the xc,yc radius and angle the angleRev is for so that there will not e
	 * ingrown fractles
	 *
	 * @param order-the degree of the fractal
	 * @param xc-the x coordinate of center
	 * @param yc-the y coordinate of center
	 * @param fractalSize-the length of the triangle
	 * @param angle
	 * @param angleRev
	 */
	public static void drawFractleCrazy(int order,double xc,double yc,double fractalSize,double angle,double angleRev){
		// draw the fractal triangle needed to be turned 60 degree and the radius halfed
		TrianglesFractle(order,xc,yc,fractalSize/2,angle+60);
		//also draw the dragon curve in the middle of the triangles
		drawDragon(order,xc,yc,angle,fractalSize);


		
		double coef=3;
		if(order==0)return;
		double length=Math.abs(fractalSize/2+(fractalSize/2)/coef);
		//distance to new center of each new triangle
		double angleOig;
		double x1;
		double y1;
		if(angle+180!=angleRev){
			angleOig=Math.toRadians(angle+180);
			x1=length*Math.cos(angleOig)+xc;
			y1=length*Math.sin(angleOig)+yc;

			//drawLine(xc,yc,length,Math.toDegrees(angleOig));

			drawFractleCrazy(order-1,x1,y1,fractalSize/coef,Math.toDegrees(angleOig),Math.toDegrees(angleOig)+180);
		}
		if(angle+60!=angleRev){
			angleOig=Math.toRadians(angle+60);
			x1=length*Math.cos(angleOig)+xc;
			y1=length*Math.sin(angleOig)+yc;


			//drawLine(xc,yc,length,Math.toDegrees(angleOig));

			drawFractleCrazy(order-1,x1,y1,fractalSize/coef,Math.toDegrees(angleOig),Math.toDegrees(angleOig)+180);
		}

		if(angle-60!=angleRev){
			angleOig=Math.toRadians(angle-60);
			x1=length*Math.cos(angleOig)+xc;
			y1=length*Math.sin(angleOig)+yc;


			//drawLine(xc,yc,length,Math.toDegrees(angleOig));

			drawFractleCrazy(order-1,x1,y1,fractalSize/coef,Math.toDegrees(angleOig),Math.toDegrees(angleOig)+180);
		}

	}

	static double degreeSin(double angle){
		return Math.sin(Math.toRadians(angle));

	}

	static double degreeCos(double angle){
		return Math.cos(Math.toRadians(angle));

	}

	public static void main(String[] args){//(String[] args) {
		// TODO Auto-generated method stub
		//drawTree(5, 0.5, 0, 90, 0.5);
		//StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.clear(arr[0]);
		drawFractleCrazy(7,0.5,0.5,0.5,0,-1);

		//TrianglesFractle(7,0.5,0.5,0.2,30);
		/*
        drawLine(0.5,0.5,0.4,0);
        drawLine(0.5,0.5,0.4,90);
        drawLine(0.5,0.5,0.4,180);
        drawLine(0.5,0.5,0.4,270);
		 */

		//drawTriangle(0.5,0.5,0.4/3,30);
	}

}

