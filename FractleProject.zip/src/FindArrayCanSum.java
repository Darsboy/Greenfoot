
/**
 * Write a description of class FindArrayCanSum here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FindArrayCanSum
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class FindArrayCanSum
     */
    int []arr={1,2,3,4,5,6,7,8,9,0};
    public FindArrayCanSum()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public boolean sampleMethod(int cur,int target,int[]arr)
    {
        // put your code here
        if(cur>=arr.length){
            return false;
        }
        return sampleMethod(cur+1,target-arr[cur],arr)||sampleMethod(cur+1,target,arr);
    }
}
