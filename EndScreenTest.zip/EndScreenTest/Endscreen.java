import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*; 
/**
 * Write a description of class Endscreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Endscreen extends World
{

    /**
     * Constructor for objects of class Endscreen.
     * 
     */
    public static int  height=600, length=(int)(height*1.6);
    public static LinkedList<Player> scoreBoard=new LinkedList<Player>();
    public Endscreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(length, height, 1); 
        //scoreBoard=k;
        //scoreBoard.add(new Player("213",40,20));
        //scoreBoard.add(new Player("Keyll",50,20));

        //scoreBoard.add(new Player(inName.getValue(),50,20));

        //Collections.sort(scoreBoard,new SortbyScore());
        Collections.sort(scoreBoard,new SortbyScore());
        for(int i=0; i<scoreBoard.size(); i+=1){
            addObject(scoreBoard.get(i),getWidth()/2,i*100+100);
        }

    }

    class SortbyScore implements Comparator<Player> 
    { 
        // Used for sorting in ascending order of 
        // roll name 
        public int compare(Player a, Player b) 
        { 
            return a.score-b.score; 
        } 
    } 

    public void act(){

        if(Greenfoot.isKeyDown("2")){
            TextBox m=new TextBox();
            m.scoreBoard=scoreBoard;
            Greenfoot.setWorld(m);
        }

    }

}
