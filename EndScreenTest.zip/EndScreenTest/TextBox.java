import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*; 
/**
 * Write a description of class TextBox here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TextBox extends World
{

    /**
     * Constructor for objects of class TextBox.
     * 
     */
    //Label input = new Label("Type Word Here", 40);
    boolean nextCap=true;
    boolean shouldUpdate=false;

    static LinkedList<Player> scoreBoard=new LinkedList<Player>();
    String d="",leading="Enter name ";
    Label display=new Label(d,60);
    public TextBox()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Endscreen.length, Endscreen.height, 1); 
        //scoreBoard.add(new Player("213",40,20));
        //scoreBoard.add(new Player("Keyll",50,20));

        //scoreBoard.add(new Player(inName.getValue(),50,20));
        addObject(display,getWidth()/2,60);
        display.setValue(leading+" "+d);
        //Collections.sort(scoreBoard,new SortbyScore());
           for(int i=0; i<scoreBoard.size(); i+=1){
                addObject(scoreBoard.get(i),getWidth()/2,i*100+100);
            }
        //prepare();
    }

    String getValue(){
        return d;
    }
    class SortbyScore implements Comparator<Player> 
    { 
        // Used for sorting in ascending order of 
        // roll name 
        public int compare(Player a, Player b) 
        { 
            return a.score-b.score; 
        } 
    } 
    int score =0;
    public void act(){
        String in=Greenfoot.getKey();
        if(shouldUpdate)display.setValue(leading+" "+d);
        if(in!=null&&!in.equals("enter")){
            shouldUpdate=true;
            if(in.equals("shift")){
                nextCap=true;
            }
            if(in.equals("space")){
                d=d+" ";
            }
            if(d.length()>0&&in.equals("backspace")){
                d=d.substring(0,d.length()-1);
            }
            else if(in.length()==1){
                if(nextCap&&Character.isLetter(in.charAt(0)))
                    d=d+(char)(in.charAt(0)+'A'-'a');
                else d=d+in;
                nextCap=false;
            }

        }else if(in!=null&&in.equals("enter")){
            nextCap=true;
            //scoreBoard.add(new Player(d,++score,60));
            Endscreen.scoreBoard.add(new Player(d,++score,60));
            removeObjects(getObjects(Player.class));
            Collections.sort(scoreBoard,new SortbyScore());
            d="";
            for(int i=0; i<scoreBoard.size(); i+=1){
                addObject(scoreBoard.get(i),getWidth()/2,i*60+100);
            }
        }

        if(Greenfoot.isKeyDown("1")){
            Endscreen m=new Endscreen();
            //Endscreen.scoreBoard=scoreBoard;
            Greenfoot.setWorld(m);
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}