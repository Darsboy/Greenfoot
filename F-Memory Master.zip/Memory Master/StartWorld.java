import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
import java.util.*;
/**
 * Write a description of class StartWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartWorld extends World
{

    /**
     * Constructor for objects of class StartWorld.
     * 
     */
    static GreenfootImage[][] cardsImages=new GreenfootImage[13][4];//rank and suit
    static GreenfootImage[][] cardsImagesSmall=new GreenfootImage[13][4];//rank and suit
    static boolean initiated=false;
    Button button=new Button();
    Label player=new Label("Welcome",40);
    public StartWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(Game.width, Game.height, 1); 
        if(!initiated){
            initiated=true;
            initiateCards();
        }
        addObject(button, getWidth()/2,50);
        addObject(player, getWidth()/2,getHeight()/2);
        Label Start=new Label("",6);
        prepare();
        Intofile.loadPlayers();
    }

    GreenfootImage getCardImage(int rank,int suit){
        int imageNumber=suit*13+rank;
        String imageName=Integer.toString(imageNumber);
        if(imageNumber<10)imageName="0"+Integer.toString(imageNumber);
        return new GreenfootImage("tile0"+imageName+".png");

    }

    public void initiateCards(){
        for(int rank=0; rank<13; rank++){
            for(int suit=0;suit<4;suit++){
                GreenfootImage k=getCardImage(rank,suit);
                k.scale(Card.height,(int)(1.6*Card.height));
                cardsImages[rank][suit]= k;
                //addObject(new Card(rank,suit),0,0);

            }
        }

    }

    public void act(){
        if(Intofile.currentPlaying!=null)
            player.setValue("Welcome\n"+Intofile.currentPlaying.name);

        if(Greenfoot.mouseClicked(button)&&Intofile.currentPlaying!=null){
            Greenfoot.setWorld(new Game(5,20,5000));
        }
        if(Greenfoot.isKeyDown("S")){

            

        }
        if(Greenfoot.isKeyDown("L")){

            Intofile.loadPlayers();
        }
        if(Greenfoot.isKeyDown("N")){
            Intofile.newPlayer();
        }
        if(Greenfoot.isKeyDown("G")){
            Intofile.getPlayer();
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
