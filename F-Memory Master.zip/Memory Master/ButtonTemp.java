import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ButtonTemp extends Actor
{
    /**
     * To shrink the image
     */
    GreenfootSound beep=new GreenfootSound("beep_high.wav");
    GreenfootImage image1 = new GreenfootImage("StartButton.PNG");
    GreenfootImage image2 = new GreenfootImage("StartButtonInverted.png");
    ButtonTemp(GreenfootImage img1,GreenfootImage img2,int sn) 
    {
        //GreenfootImage image = getImage();
        beep.setVolume(85);
        image1=img1;
        image1.scale(image1.getWidth()/sn, image1.getHeight() /sn);
        image2=img2;
        image2.scale(image2.getWidth()/sn, image2.getHeight() /sn);
        setImage(image1);
        //image.scale(image.getWidth()/2, image.getHeight() /2);
        //setImage(image);
    }
    boolean needPlay=true;
    public void act(){
        // changes sprite when the curser is over it
        if (Greenfoot.mouseMoved(this)){
            

            if(needPlay){beep.play();needPlay=false;}

           
            setImage(image1);
        }
        if (Greenfoot.mouseMoved(null) && !Greenfoot.mouseMoved(this))
        {
            needPlay=true;
            
            
            setImage(image2);
        }
    }
}
