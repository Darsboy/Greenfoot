import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Button extends Actor
{
    /**
     * To shrink the image
     */
    GreenfootSound beep=new GreenfootSound("beep_high.wav");
    Button() 
    {
        GreenfootImage image = getImage();
        beep.setVolume(85);
        image.scale(image.getWidth()/2, image.getHeight() /2);
        setImage(image);
    }
    boolean needPlay=true;
    public void act(){
        // changes sprite when the curser is over it
        if (Greenfoot.mouseMoved(this)){
            GreenfootImage image = new GreenfootImage("StartButton.PNG");

            if(needPlay){beep.play();needPlay=false;}

            image.scale(image.getWidth()/2, image.getHeight() /2);
            setImage(image);
        }
        if (Greenfoot.mouseMoved(null) && !Greenfoot.mouseMoved(this))
        {
            needPlay=true;
            GreenfootImage image = new GreenfootImage("StartButtonInverted.png");
            image.scale(image.getWidth()/2, image.getHeight() /2);
            setImage(image);
        }
    }
}
